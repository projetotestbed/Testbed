/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.ufg.inf.wm;

import java.sql.Connection;
import java.sql.DriverManager;

/**
 *
 * @author douglas
 */
public class DbConnection {

    private static final String JDBC_DRIVER = "org.apache.derby.jdbc.EmbeddedDriver";
    private static final String URL = 
            "jdbc:derby://localhost:1527/"
            + "water_monitor_db;" ;
            //+ "create=true"  
            //+ "user=water;"
            //+ "password=senha123"
           // + "\n";

    public static Connection getConnection() {
        try {
            Class.forName(JDBC_DRIVER);
            return DriverManager.getConnection(URL);
        } catch (ClassNotFoundException e) {
            System.out.println("Problems with the driver.");
        } catch (Exception e) {
            System.out.println("Problems with user and password.");
        }
        return null;
    }
}
