package br.ufg.inf.wm;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Desktop;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.LinkedList;
import javax.swing.AbstractListModel;
import java.net.DatagramPacket;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;
import java.util.Vector;
import javax.swing.BoxLayout;
import javax.swing.DefaultComboBoxModel;
import javax.swing.Timer;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.plot.XYPlot;
import org.jfree.data.time.Millisecond;
import org.jfree.data.time.TimeSeries;
import org.jfree.data.time.TimeSeriesCollection;

/**
 *
 * @author brunoos
 */
public class WMonitor extends javax.swing.JFrame implements ActionListener {

    // numero de coletas por sensor
    private static final int COLLECT_NUM = 5;
    // intervalo de tempo entre cada coleta
    private static final int COLLECTION_INTERVAL = 1000; //millisec
    // Indice do vetor que relaciona o tipo de dado do sensor selecionado
    // na comboBox e
    // indica o tipo de dado selecionado na interface
    // para plotar o gráfigo (luminosidade, oxigenio, temperatura)
    private int selectedData;
    // Indica o ip do sensor selecionado na interface
    private String ipSensor;
    // Array que contem os IPs dos sensores da RSSF
    private ArrayList<InetAddress> ipMap = new ArrayList<InetAddress>();
    // Vetor que adiciona elementos a comboBox de IPs de sensores
    private Vector<String> sensors_label = new Vector<String>();
    // Vetor com os elementos da comboBox de dados dos sensores
    // (temperatura, luminosidade, oxigenio)
    private Vector<String> data = new Vector<String>();
    // Array que receberá do banco de dados dos sensores
    // (temperatura, luminosidade, oxigenio)
    private List<WaterData> waterData = new ArrayList<WaterData>();
    // Mapeia IDs de coleta com endereços IP:
    // Cada sensor realiza um determinado numero de coletas (COLLECT_NUM)
    // Essas coletas são numeradas e mapeadas ao sensor correspondente
    private HashMap<InetAddress, Integer> collectionIdMap;
    // Controla o intervalo de tempo e as informações a serem
    // são plotadas nos gráficos
    private TimeSeries series;
    // Flag: caso seja verdadeira, a comboBox com os endereços IP dos
    // sensores deve ser atualizada. Ver método initComboBox1()
    boolean initializedCombobox = false;
    ChartPanel cp;
    // Controla o intervalo de tempo para plotagem dos gráficos
    private Timer timer = new Timer(100, this);

    private class MyModel extends AbstractListModel<String> {

        private List<String> list = new LinkedList<String>();

        public synchronized void add(String s) {
            list.add(s);
            int i = list.size() - 1;
            fireIntervalAdded(this, i, i);
        }

        public synchronized void clean() {
            int i = list.isEmpty() ? 0 : list.size() - 1;
            list.clear();
            fireIntervalRemoved(this, 0, i);
        }

        @Override
        public synchronized int getSize() {
            return list.size();
        }

        @Override
        public synchronized String getElementAt(int index) {
            return list.get(index);
        }
    }
    private MyModel model;
    private Communication comm;
    private Map<InetAddress, Short> serials;
    private long startTime;
    private Sensor sensorMap;

    /**
     * Creates new form WMonitor
     */
    public WMonitor() {
        initComponents();
        pack();
        model = new MyModel();
        //new WaterDataDao().createDataTable();
        jList1.setModel(model);
        serials = new HashMap<InetAddress, Short>();
        sensorMap = new Sensor();
        startTime = System.currentTimeMillis();
        comm = new Communication(this);
        comm.start();
        initComboBox1();
        initComboBox2();
        initPanels();
    }

    // Processa os datagramas com os dados coletados pelos sensores
    public void processPacket(DatagramPacket packet) {

        // "Empacota" os dados recebidos em um array de bytes
        ByteBuffer bf = ByteBuffer.wrap(packet.getData());

        // Ordem dos bytes        
        bf.order(ByteOrder.BIG_ENDIAN);

        // Serial
        short sRecv = bf.getShort(0);
        Short sLocal = serials.get(packet.getAddress());

        // Se o último serial recebido for diferente do serial anterior 
        if (sLocal == null || sRecv != sLocal.shortValue()) {

            // mapeia serial de acordo com o endereço IP do sensor
            serials.put(packet.getAddress(), sRecv);

            model.add((System.currentTimeMillis() - startTime)
                    + ": Received data from "
                    + packet.getAddress()
                    + " SERIAL: " + bf.getShort(0));

            // Controla tempo de coleta, contabilizado quando o dado 
            // é recebido por esta aplicação
            Timestamp collection_time = new Timestamp(Calendar.getInstance()
                    .getTime().getTime());

            // Armazena IP do sensor no array, caso ele ainda 
            // não esteja armazenado
            sensorMap.mapIp(packet.getAddress());

            // Variável de instancia para mapear os IDs de coleta
            collectionIdMap = new HashMap<InetAddress, Integer>();

            // Inicializa IDs coletas dos sensores do 
            // mapa collectionIdMap com zero
            sensorMap.initCollectionMap(collectionIdMap);

            // Percorre array de bytes coletando as informações dos sensores
            for (int j = 0; j < COLLECT_NUM; j++) {
                Water water = new Water(
                        (double) (0x0000FFFF
                        & bf.getShort(2 + (j * COLLECT_NUM + 0))),
                        (double) (0x0000FFFF
                        & bf.getShort(2 + (j * COLLECT_NUM + 2))),
                        (double) (0x0000FFFF
                        & bf.getShort(2 + (j * COLLECT_NUM + 4))),
                        (double) (0x0000FFFF
                        & bf.getShort(2 + (j * COLLECT_NUM + 6))));
                /*
                 System.out.println("Photo0: " + water.getPhoto0());
                 System.out.println("Photo1: " + water.getPhoto1());
                 System.out.println("  Temp: " + water.getTemperature());
                 System.out.println("  Oxyg: " + water.getOxygen());
                 */
                // Instancia de objeto a ser inserido no banco de dados
                WaterData wt = new WaterData(sensorMap, water, collection_time);

                // ID de coleta correspondente a coleta atual
                int idColeta =
                        sensorMap.mapCollectionId(collectionIdMap,
                        sensorMap.getIp());

                // Atualizando id de coleta do objeto
                wt.setCollection_id(idColeta);

                // Contabilizando o tempo de coleta: 
                // tentativa de aproximar ao momento em que o sensor
                // realizou a coleta.
                // para isso subtrai-se o momento atual menos o intervalo de 
                // tempo entre cada coleta.
                collection_time =
                        wt.subtractCollectionTime(collection_time,
                        COLLECTION_INTERVAL);
                WaterDataDao wtd = new WaterDataDao();
                wtd.insert(wt);
            }

            // Envio do ACK para o sensor
            comm.send(packet.getAddress(), packet.getPort(), sRecv);

            // Se o serial que acabou de ser recebido
            // for igual ao recebido anteriormente
        } else if (sLocal.shortValue() == sRecv) {

            // Ignora os dados recebidos, e envia o serial de volta 
            // (talvez porque o último foi perdido)
            model.add((System.currentTimeMillis() - startTime)
                    + ": Duplicated data from " + packet.getAddress()
                    + " SERIAL:" + bf.getShort(0));
            comm.send(packet.getAddress(), packet.getPort(), sRecv);
        }
        // Scroll down
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                jScrollPane1.
                        getVerticalScrollBar().
                        setValue(jScrollPane1.getVerticalScrollBar()
                        .getMaximum());
            }
        });
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel3 = new javax.swing.JPanel();
        jPanel1 = new javax.swing.JPanel();
        jToolBar1 = new javax.swing.JToolBar();
        jPanel2 = new javax.swing.JPanel();
        jPanel4 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jComboBox1 = new javax.swing.JComboBox();
        jLabel3 = new javax.swing.JLabel();
        jComboBox2 = new javax.swing.JComboBox();
        jToggleButton1 = new javax.swing.JToggleButton();
        jPanel5 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jList1 = new javax.swing.JList();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel3.setBackground(new java.awt.Color(254, 254, 254));

        jPanel1.setLayout(new javax.swing.BoxLayout(jPanel1, javax.swing.BoxLayout.LINE_AXIS));

        jToolBar1.setRollover(true);
        jPanel1.add(jToolBar1);

        jLabel2.setFont(new java.awt.Font("Ubuntu", 1, 18)); // NOI18N
        jLabel2.setText("Selecionar Sensor");

        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        jComboBox1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox1ActionPerformed(evt);
            }
        });

        jLabel3.setFont(new java.awt.Font("Ubuntu", 1, 18)); // NOI18N
        jLabel3.setText("Selecionar Dado");

        jComboBox2.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        jComboBox2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox2ActionPerformed(evt);
            }
        });

        jToggleButton1.setFont(new java.awt.Font("Ubuntu", 1, 18)); // NOI18N
        jToggleButton1.setText("Plotar Gráfico");
        jToggleButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jToggleButton1ActionPerformed(evt);
            }
        });

        org.jdesktop.layout.GroupLayout jPanel4Layout = new org.jdesktop.layout.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .add(jPanel4Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(jLabel2)
                    .add(jLabel3))
                .add(18, 18, 18)
                .add(jPanel4Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING, false)
                    .add(jToggleButton1, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 149, Short.MAX_VALUE)
                    .add(jComboBox2, 0, 149, Short.MAX_VALUE)
                    .add(jComboBox1, 0, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(48, Short.MAX_VALUE))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jPanel4Layout.createSequentialGroup()
                .addContainerGap(org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .add(jPanel4Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(jLabel2)
                    .add(jComboBox1, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .add(18, 18, 18)
                .add(jPanel4Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(jLabel3)
                    .add(jComboBox2, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .add(26, 26, 26)
                .add(jToggleButton1))
        );

        jList1.setModel(new javax.swing.AbstractListModel() {
            String[] strings = { "Item 1", "Item 2", "Item 3", "Item 4", "Item 5" };
            public int getSize() { return strings.length; }
            public Object getElementAt(int i) { return strings[i]; }
        });
        jScrollPane1.setViewportView(jList1);

        org.jdesktop.layout.GroupLayout jPanel5Layout = new org.jdesktop.layout.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jPanel5Layout.createSequentialGroup()
                .add(jScrollPane1)
                .addContainerGap())
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jPanel5Layout.createSequentialGroup()
                .add(jScrollPane1, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 145, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .add(0, 0, Short.MAX_VALUE))
        );

        org.jdesktop.layout.GroupLayout jPanel2Layout = new org.jdesktop.layout.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jPanel2Layout.createSequentialGroup()
                .add(jPanel4, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jPanel5, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jPanel2Layout.createSequentialGroup()
                .add(jPanel5, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
            .add(jPanel2Layout.createSequentialGroup()
                .add(jPanel4, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .add(0, 0, Short.MAX_VALUE))
        );

        org.jdesktop.layout.GroupLayout jPanel3Layout = new org.jdesktop.layout.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(org.jdesktop.layout.GroupLayout.TRAILING, jPanel1, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 848, Short.MAX_VALUE)
            .add(org.jdesktop.layout.GroupLayout.TRAILING, jPanel2, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jPanel3Layout.createSequentialGroup()
                .add(jPanel2, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jPanel1, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 457, Short.MAX_VALUE))
        );

        getContentPane().add(jPanel3, java.awt.BorderLayout.CENTER);

        java.awt.Dimension screenSize = java.awt.Toolkit.getDefaultToolkit().getScreenSize();
        setBounds((screenSize.width-858)/2, (screenSize.height-650)/2, 858, 650);
    }// </editor-fold>//GEN-END:initComponents

    private void jComboBox1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox1ActionPerformed

        // ComboBox Selecionar Sensor: Se a opção selecionada for
        // "Atualizar Lista", inicializar a comboBox novamente
        // para carregar os IPs dos sensores
        if (jComboBox1.getSelectedIndex() == 0) {
            initComboBox1();
        } else {

            // Caso tenha sido selecionado algum IP da lista,
            // atualiza ipSensor 
            // (variavel utilizada para plotar o grafico de acordo com o sensor)
            ipSensor = (String) jComboBox1.
                    getItemAt(jComboBox1.getSelectedIndex());
        }
    }//GEN-LAST:event_jComboBox1ActionPerformed

    private void jToggleButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jToggleButton1ActionPerformed
        createChart(selectedData, ipSensor);
    }//GEN-LAST:event_jToggleButton1ActionPerformed

    private void jComboBox2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox2ActionPerformed
        selectedData = jComboBox2.getSelectedIndex();
    }//GEN-LAST:event_jComboBox2ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Create and display the form */

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    WaterDataDao wt = new WaterDataDao();
                    if (new WaterDataDao().isTableExist("DATA") == true) {
                        wt.deleteTable(); // apaga dados
                        System.out.println("Dados da tabela foram apagados.");
                    }
                } catch (SQLException e) {
                    e.printStackTrace();
                }
                new WMonitor().setVisible(true);
            }
        });
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JComboBox jComboBox1;
    private javax.swing.JComboBox jComboBox2;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JList jList1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JToggleButton jToggleButton1;
    private javax.swing.JToolBar jToolBar1;
    // End of variables declaration//GEN-END:variables

    public void initComboBox1() {
        if (initializedCombobox == false) {
            sensors_label.add(0, "Atualizar Lista"); // index 0
            initializedCombobox = true;
        } else {
            // Toda vez que for selecionada a opção "Atualizar Lista",
            // todos os seus elementos serão removidos para serem inseridos
            // posteriormente novamente com os novos elementos.
            // A posição zero do vetor sensors_label não pode ser removida, 
            // pois nessa está a opção de "Atualizar Lista"
            if (sensors_label.size() > 1) {
                for (int i = sensors_label.size() - 1; i > 0; i--) {
                    sensors_label.remove(i);
                }
            }

            // Atualizando comboBox inserindo os IPs do mapa de IPs IpMap
            if (sensorMap.isIpMapEmpty() == false) {
                for (int i = 0; i < sensorMap.getIpMapSize(); i++) {
                    sensors_label.add(i + 1, ""
                            + sensorMap.getIpMap(i).getHostAddress());
                }
            }
        }
        jComboBox1.setModel(new DefaultComboBoxModel(sensors_label));
        jComboBox1.setSelectedIndex(0);
    }

    public void initComboBox2() {
        data.add("Temperatura");
        data.add("Oxigênio");
        data.add("Luminosidade (1)");
        data.add("Luminosidade (2)");

        jComboBox2.setModel(new DefaultComboBoxModel(data));
        jComboBox2.setSelectedIndex(0);
    }

    public void initPanels() {
        jPanel3.setLayout(new BorderLayout());
        jPanel3.add(jPanel2, BorderLayout.PAGE_START);
        jPanel3.add(jPanel1, BorderLayout.PAGE_END);
        jPanel2.setBackground(Color.white);
        jPanel2.setSize(400, jPanel3.getWidth());
        jPanel4.setBackground(Color.white);
        jPanel5.setBackground(Color.white);

    }

    // Assim que o botão "Plotar gráfico" é acionado,
    // os dados selecionados são capturados para realização da
    // busca no banco de dados
    public void actionPerformed(final ActionEvent e) {

        WaterDataDao wt = new WaterDataDao();

        // Lê as informações do banco de dados
        waterData = wt.readDataPerSensor(ipSensor);

        // Após percorrer o array contendo as informações recuperadas do 
        // banco de dados, adiciona-se as mesmas a estrutura de dados (series)
        // de onde o gráfico será gerado
        for (WaterData w : waterData) {
            if (selectedData == 0) {
                series.addOrUpdate(
                        new Millisecond(w.getCollectionTime()),
                        w.getWater().getTemperature());
            } else {
                if (selectedData == 1) {
                    series.addOrUpdate(
                            new Millisecond(w.getCollectionTime()),
                            w.getWater().getOxygen());
                } else {
                    if (selectedData == 2) {
                        series.addOrUpdate(
                                new Millisecond(w.getCollectionTime()),
                                w.getWater().getPhoto0());
                    } else {
                        if (selectedData == 3) {
                            series.addOrUpdate(
                                    new Millisecond(w.getCollectionTime()),
                                    w.getWater().getPhoto1());
                        }
                    }
                }
            }
        }
    }

    // Plota o grafico de acordo com o dado do sensor selecionado (data)
    // e com o sensor (ipSensor)
    public void createChart(int data, String ipSensor) {

        ArrayList<String> titleArray = new ArrayList<String>();
        ArrayList<String> xAxeArray = new ArrayList<String>();
        ArrayList<String> txt_subtitleArray = new ArrayList<String>();

        // Define titulos e sub-titulos dos graficos
        txt_subtitleArray.add("Temperature (°C)");
        txt_subtitleArray.add("Oxygen ");
        txt_subtitleArray.add("Luminosity ");
        txt_subtitleArray.add("Luminosity ");

        titleArray.add("Sensor " + ipSensor + " - Temperature");
        titleArray.add("Sensor " + ipSensor + " - Oxygen");
        titleArray.add("Sensor " + ipSensor + " - Luminosity [1]");
        titleArray.add("Sensor " + ipSensor + " - Luminosity [2]");


        String title = titleArray.get(data);
        String xAxe = "HH:mm:ss";
        String txt_subtitle = txt_subtitleArray.get(data);

        this.series = new TimeSeries(titleArray.get(data));

        timer.setInitialDelay(1000);

        TimeSeriesCollection dataset = new TimeSeriesCollection();

        dataset.addSeries(series);

        boolean subtitle = true;
        boolean tooltips = true;
        boolean urls = true;

        JFreeChart chart = ChartFactory.createTimeSeriesChart(
                title, // title
                xAxe, // x-axis label
                txt_subtitle, // y-axis label
                dataset, // data
                true, // create legend?
                true, // generate tooltips?
                false // generate URLs?
                );

        //ChartPanel cp = new ChartPanel(chart, true);
        cp = new ChartPanel(chart, true);
        final XYPlot plot = chart.getXYPlot();

        // configurações de layout do gráfico
        plot.setBackgroundPaint(new Color(0xffffe0));
        plot.setDomainGridlinesVisible(true);
        plot.setDomainGridlinePaint(Color.lightGray);
        plot.setRangeGridlinesVisible(true);
        plot.setRangeGridlinePaint(Color.lightGray);

        ValueAxis xaxis = plot.getDomainAxis();


        xaxis.setAutoRange(true);
        //Domain axis would show data of 60 seconds for a time
        xaxis.setFixedAutoRange(40000.0);  // 40 seconds
        //xaxis.setVerticalTickLabels(true);
        ValueAxis yaxis = plot.getRangeAxis();

        yaxis.setRange(0.0, 200.0);

        jPanel1.setLayout(new BoxLayout(jPanel1, BoxLayout.PAGE_AXIS));
        jPanel1.removeAll();
        jPanel1.add(cp);

        //cp.setSize(jPanel1.getWidth(), jPanel1.getHeight());
        cp.setAlignmentY(ChartPanel.CENTER_ALIGNMENT);
        cp.setAlignmentX(ChartPanel.CENTER_ALIGNMENT);
        cp.setPreferredSize(new Dimension(750, 430));
        cp.setMaximumSize(new Dimension(2000, 730));
        cp.setVisible(true);

        jPanel1.revalidate();
        jPanel1.repaint();
        jPanel1.setBackground(Color.white);
        jPanel1.setVisible(true);

        timer.start();
    }
}
