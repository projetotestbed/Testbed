/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.ufg.inf.wm;

import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author douglas
 */
public class WaterDataDao {

    public boolean isTableExist(String sTablename) throws SQLException {
        Connection connection = DbConnection.getConnection();;
        if (connection != null) {
            DatabaseMetaData dbmd = connection.getMetaData();
            ResultSet rs = dbmd.getTables(null, null,
                    sTablename.toUpperCase(), null);
            if (rs.next()) {
                System.out.println("Tabela "
                        + rs.getString("TABLE_NAME")
                        + " já existe. Utilizando tabela já existente.");
            } else {
                createDataTable();
            }
            return true;
        }
        return false;
    }

    public boolean createDataTable() {
        String sTableName = "DATA";
        try {
            Connection con = DbConnection.getConnection();

            if (con != null) {
                DatabaseMetaData dbmd = con.getMetaData();
                ResultSet rs = dbmd.getTables(null, null,
                        sTableName.toUpperCase(), null);
                if (rs.next()) {
                    System.out.println("Using table already existent");
                } else {

                    try {
                        String com = ""
                                + "CREATE TABLE DATA ("
                                + " COLLECTION_ID INTEGER NOT NULL,"
                                + " TEMPERATURE INTEGER,"
                                + " OXYGEN INTEGER,"
                                + " PHOTO0 INTEGER,"
                                + " PHOTO1 INTEGER,"
                                + " COLLECTION_TIME TIMESTAMP NOT NULL PRIMARY KEY,"
                                + " SENSOR_IP CHAR(39) NOT NULL"
                                + ")";
                        Statement stmt = con.createStatement();
                        stmt.executeUpdate(com);
                        con.commit();
                        stmt.close();
                        return true;

                    } finally {
                        con.close();
                    }
                }
                return true;
            }
            return false;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean deleteTable() {
        try {
            Connection con = DbConnection.getConnection();
            try {
                String com = "DELETE FROM DATA WHERE COLLECTION_ID >= 0";
                Statement stmt = con.createStatement();
                stmt.executeUpdate(com);
                con.commit();
                stmt.close();
                return true;

            } finally {
                con.close();
            }
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean insert(WaterData data) {

        try {
            Connection con = DbConnection.getConnection();
            try {
                String sqlIns = ""
                        + "INSERT INTO DATA"
                        + " ("
                        + "     COLLECTION_ID, "
                        + "     SENSOR_IP, "
                        + "     COLLECTION_TIME, "
                        + "     TEMPERATURE, "
                        + "     OXYGEN, "
                        + "     PHOTO0, "
                        + "     PHOTO1"
                        + " ) "
                        + "VALUES (?, ?, ?, ?, ?, ?, ?)";
                PreparedStatement pstmt = con.prepareStatement(sqlIns);
                pstmt.setInt(1, data.getCollection_id());
                pstmt.setString(2, data.getSensor().getStringIp());
                pstmt.setTimestamp(3, data.getCollectionTime());
                pstmt.setDouble(4, data.getWater().getTemperature());
                pstmt.setDouble(5, data.getWater().getOxygen());
                pstmt.setDouble(6, data.getWater().getPhoto0());
                pstmt.setDouble(7, data.getWater().getPhoto1());
                int qnt = pstmt.executeUpdate();
                pstmt.close();
                if (qnt != 1) {
                    System.out.println("Problemas ao inserir.");
                }
                return true;
            } finally {
                con.close();
            }
        } catch (Exception e) {
            System.out.println("Problemas na inserção.");
            e.printStackTrace();
            return false;
        }

    }

    public List<WaterData> readDataPerSensor(String sensorIp) {
        //System.out.println("LENDO SENSOR "+sensorId);

        List<WaterData> result = new ArrayList<WaterData>();
        try {
            Connection con = DbConnection.getConnection();

            try {
                String sqlSelect = ""
                        + "SELECT "
                        + " COLLECTION_ID, "
                        + " TEMPERATURE, "
                        + " OXYGEN, "
                        + " PHOTO0, "
                        + " PHOTO1, "
                        + " COLLECTION_TIME, "
                        + " SENSOR_IP  "
                        + "FROM DATA "
                        + "WHERE "
                        + " SENSOR_IP=? "
                        + "ORDER BY COLLECTION_ID";
                PreparedStatement pstmt = con.prepareStatement(sqlSelect);
                pstmt.setString(1, sensorIp);
                ResultSet rs = pstmt.executeQuery();

                completeResult1(result, rs);
                rs.close();
            } finally {
                con.close();
            }

        } catch (SQLException e) {
            System.out.println("Não foi possível consultar os registros:");
            e.printStackTrace();
        }// try .. catch

        return result;
    }

    private void completeResult1(List<WaterData> result, ResultSet rs)
            throws SQLException {
        while (rs.next()) {
            WaterData wt = new WaterData();
            Sensor s = new Sensor();
            Water w = new Water();

            wt.setCollection_id(rs.getInt(1));
            w.setTemperature(rs.getDouble(2));
            w.setOxygen(rs.getDouble(3));
            w.setPhoto0(rs.getDouble(4));
            w.setPhoto1(rs.getDouble(5));
            wt.setCollection_time(rs.getTimestamp(6));
            s.setStringIp(rs.getString(7));

            wt.setSensor(s);
            wt.setWater(w);
            result.add(wt);
        }
    }
}
