/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.ufg.inf.wm;

import java.sql.Timestamp;
import java.util.Calendar;
import java.sql.Date;
import java.util.List;

/**
 *
 * @author douglas
 */
public class WaterData {

    private int collectionId;
    private Sensor sensor;
    private Water water;
    private Timestamp collectionTime;

    public WaterData(Sensor sensor, Water water, Timestamp collection_time) {
        this.sensor = sensor;
        this.water = water;
        this.collectionTime = collection_time;
    }

    public WaterData() {
    }

    public int getCollection_id() {
        return collectionId;
    }

    public void setCollection_id(int collection_id) {
        this.collectionId = collection_id;
    }

    public Sensor getSensor() {
        return sensor;
    }

    public void setSensor(Sensor sensor) {
        this.sensor = sensor;
    }

    public Water getWater() {
        return water;
    }

    public void setWater(Water water) {
        this.water = water;
    }

    public Timestamp getCollectionTime() {
        //return new Timestamp(Calendar.getInstance().getTime().getTime());        
        return this.collectionTime;
    }

    public void setCollection_time(Timestamp collection_time) {
        this.collectionTime = collection_time;
    }

    public Timestamp subtractCollectionTime(Timestamp currentTime, int time) {
        currentTime.getTime();
        Timestamp before = new Timestamp(currentTime.getTime() - time);
        return before;
    }
}
