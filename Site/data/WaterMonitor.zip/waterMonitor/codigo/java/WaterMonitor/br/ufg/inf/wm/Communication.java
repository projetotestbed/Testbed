package br.ufg.inf.wm;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;

/**
 *
 * @author brunoos
 */
public class Communication extends Thread {

    private DatagramSocket socket;
    private WMonitor monitor;

    public Communication(WMonitor m) {
        monitor = m;
        try {
            socket = new DatagramSocket(9000);
        } catch (SocketException e) {
            e.printStackTrace();
        }
    }
    
    public Communication(){}

    public void run() {
        while (true) {
            try {
                // Array de bytes onde os dados coletados dos sensores
                // serão armazenados
                ByteBuffer bf = ByteBuffer.allocate(128);
                DatagramPacket rPacket = new DatagramPacket(bf.array(), bf.capacity());
                // aguarda recebimento de pacotes enviados pelos sensores
                socket.receive(rPacket);
                monitor.processPacket(rPacket);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    // Envia o ACK para os motes
    public void send(InetAddress addr, int port, short serial) {
        try {
            ByteBuffer bf = ByteBuffer.allocate(3);
            bf.order(ByteOrder.BIG_ENDIAN);
            bf.put((byte)1);
            bf.putShort(serial);
            DatagramPacket sPacket = new DatagramPacket(bf.array(), bf.capacity());
            sPacket.setAddress(addr);
            sPacket.setPort(port);
            socket.send(sPacket);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
