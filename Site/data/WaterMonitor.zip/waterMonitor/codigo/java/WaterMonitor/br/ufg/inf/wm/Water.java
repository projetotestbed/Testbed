/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.ufg.inf.wm;

/**
 *
 * @author douglas
 */
public class Water {
    private double photo0;
    private double photo1;
    private double temperature;
    private double oxygen;

    public Water(double photo0, double photo1, double temperature, double oxygen) {
        this.photo0 = photo0;
        this.photo1 = photo1;
        this.temperature = temperature;
        this.oxygen = oxygen;
    }

    public Water() {
    }
    
    public double getPhoto0() {
        return photo0;
    }

    public void setPhoto0(double photo0) {
        this.photo0 = photo0;
    }

    public double getPhoto1() {
        return photo1;
    }

    public void setPhoto1(double photo1) {
        this.photo1 = photo1;
    }

    public double getTemperature() {
        return temperature;
    }

    public void setTemperature(double temperature) {
        this.temperature = temperature;
    }

    public double getOxygen() {
        return oxygen;
    }

    public void setOxygen(double oxygen) {
        this.oxygen = oxygen;
    }
}
