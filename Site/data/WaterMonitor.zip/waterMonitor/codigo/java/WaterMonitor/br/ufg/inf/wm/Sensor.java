/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.ufg.inf.wm;

import java.net.Inet6Address;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 *
 * @author douglas
 */
public class Sensor {

    private int id;
    private ArrayList<InetAddress> ipMap;
    private InetAddress ip;

    public Sensor() {
        this.ipMap = new ArrayList<InetAddress>();
    }

    public Sensor(int id) {
        this.id = id;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public InetAddress getIp() {
        return this.ip;
    }

    public String getStringIp() {
        return ip.getHostAddress();
    }

    // pega a string que representa um IP de sensor do banco de dados
    // e converte em um tipo de dado de endereço IPv6
    // Esse método, entretanto, somente é utilizado para capturar a string
    // retornada após a consulta no banco de dados 
    // (WaterDataDao.completeResult1), por isso a exceção
    // não foi tratada
    public void setStringIp(String ip) {
        try {
            this.ip = InetAddress.getByName(ip);
        } catch (UnknownHostException e) {
            //System.out.println("Não foi possível converter o endereço " + ip);
            //e.printStackTrace();
        }
    }

    public void setIp(InetAddress ip) {
        this.ip = ip;
    }

    // Adiciona IPs dos sensores à lista de IPs, caso não esteja lá ainda
    public void mapIp(InetAddress ip) {
        if (!ipMap.contains(ip)) {
            ipMap.add(ip);
        }
        setIp(ipMap.get(ipMap.indexOf(ip)));
    }

    public InetAddress getIpMap(int index) {
        return ipMap.get(index);
    }

    public int getIpMapSize() {
        return ipMap.size();
    }

    public boolean isIpMapEmpty() {
        return ipMap.isEmpty();
    }

    // Inicializa com zero a lista que contem o numero de 
    // coletas realizados por um determinado sensor
    public void initCollectionMap(HashMap<InetAddress, Integer> collectionIdMap) {
        for (int i = 0; i < ipMap.size(); i++) {
            collectionIdMap.put(ipMap.get(i), 0);
        }
    }

    // Incrementa o id de coleta de um determinado sensor
    public int mapCollectionId(HashMap<InetAddress, Integer> collectionIdMap,
            InetAddress sensorIp) {
        int lastCollection = collectionIdMap.get(sensorIp);
        for (int i = 0; i < ipMap.size(); i++) {
            collectionIdMap.put(sensorIp, lastCollection + 1);
        }
        return lastCollection + 1;
    }
}
