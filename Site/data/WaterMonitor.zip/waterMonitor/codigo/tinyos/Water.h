#ifndef WATER_H
#define WATER_H

#define COLLECT_PERIOD 	1000 // 20 In seconds
#define ACK_WAIT_TIME 	1000 // 10 In seconds

#define MAX_RETRANSMISSIONS 3
#define MAX_DATA_SET 5
#define DATA_NUM 4 // Number of data being collected

#define SERVER "fec0::100"
typedef nx_struct data_s {
	nx_uint16_t d1;
	nx_uint16_t d2;
	nx_uint16_t d3;
	nx_uint16_t d4;
} data_t;

typedef nx_struct packet_s {
	nx_uint16_t serial;
	data_t vet[MAX_DATA_SET];
} packet_t;

typedef nx_struct ack_s {
  nx_uint8_t ack;   // será 1
  nx_uint16_t serial;
} ack_t;

#endif
