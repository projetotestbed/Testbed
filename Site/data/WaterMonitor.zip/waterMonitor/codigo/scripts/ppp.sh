#!/bin/bash

sudo pppd debug passive noauth nodetach 115200 socket 146.164.247.234:10007 \
  nocrtscts nocdtrcts lcp-echo-interval 0 noccp noip ipv6 ::23,::24 
