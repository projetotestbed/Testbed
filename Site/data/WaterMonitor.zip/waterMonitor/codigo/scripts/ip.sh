#!/bin/bash

sudo ifconfig ppp0 add fec0::100/64
