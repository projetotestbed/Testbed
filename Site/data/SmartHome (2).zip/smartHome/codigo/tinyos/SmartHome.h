#ifndef SMARTHOME_H
#define SMARTHOME_H

/* --- Estruturas genéricas --- */

typedef nx_struct cmd_s {
  nx_uint8_t id;
  nx_uint8_t info;
} cmd_t;

typedef nx_struct cmdf_s {
  nx_uint8_t id;
  nx_float info;	
} cmdf_t;


/* --- Estruturas com atributos específicos --- 
 ---	 de cada aplicação para retorno de status ---
*/

typedef nx_struct tv_status_s {
  nx_uint8_t id;
  nx_uint8_t on_off;
  nx_uint8_t channel;
  nx_uint8_t volume;
} tv_status_t;

typedef nx_struct radio_status_s {
  nx_uint8_t id;
  nx_uint8_t on_off;
  nx_float station;
  nx_uint8_t volume;
} radio_status_t;

typedef nx_struct termostato_status_s {
  nx_uint8_t id;
  nx_uint8_t on_off;
  nx_float temperature;
} termostato_status_t;

typedef nx_struct fogao_status_s {
  nx_uint8_t id;
  nx_uint8_t status_boca1;
  nx_uint8_t status_boca2;
  nx_uint8_t status_boca3;
  nx_uint8_t status_boca4;
  nx_uint8_t status_forno;
  nx_float temperature;
} fogao_status_t;



enum {
  CMD_TURN        = 1,

  GET_STATUS      = 2,	
  GET_CHANNEL     = 3,
  GET_VOLUME      = 4,
  GET_TEMPERATURE = 5,
  GET_STATION     = 6,

  SET_CHANNEL     = 7,
  SET_VOLUME      = 8,	
  SET_TEMPERATURE = 9,	
  SET_STATION     = 10,

  RESP_GET_STATUS       = 11,
  RESP_GET_CHANNEL      = 12,
  RESP_GET_VOLUME       = 13,
  RESP_GET_TEMPERATURE  = 14,
  RESP_GET_STATION      = 15,
};

enum {
  TURN_ON    = 1,
  TURN_OFF   = 2,
};
#endif
