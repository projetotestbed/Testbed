#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "contiki.h"
#include "contiki-net.h"


/* Define which resources to include to meet memory constraints. */
#define REST_RES_STATUS 1

#include "erbium.h"
#include "er-coap-13.h"

#if defined (PLATFORM_HAS_BUTTON)
#include "dev/button-sensor.h"
#endif
#if defined (PLATFORM_HAS_LEDS)
#include "dev/leds.h"
#endif
#if defined (PLATFORM_HAS_LIGHT)
#include "dev/light-sensor.h"
#endif

#define DEBUG 0
#if DEBUG
#define PRINTF(...) printf(__VA_ARGS__)
#define PRINT6ADDR(addr) PRINTF("[%02x%02x:%02x%02x:%02x%02x:%02x%02x:%02x%02x:%02x%02x:%02x%02x:%02x%02x]", ((uint8_t *)addr)[0], ((uint8_t *)addr)[1], ((uint8_t *)addr)[2], ((uint8_t *)addr)[3], ((uint8_t *)addr)[4], ((uint8_t *)addr)[5], ((uint8_t *)addr)[6], ((uint8_t *)addr)[7], ((uint8_t *)addr)[8], ((uint8_t *)addr)[9], ((uint8_t *)addr)[10], ((uint8_t *)addr)[11], ((uint8_t *)addr)[12], ((uint8_t *)addr)[13], ((uint8_t *)addr)[14], ((uint8_t *)addr)[15])
#define PRINTLLADDR(lladdr) PRINTF("[%02x:%02x:%02x:%02x:%02x:%02x]",(lladdr)->addr[0], (lladdr)->addr[1], (lladdr)->addr[2], (lladdr)->addr[3],(lladdr)->addr[4], (lladdr)->addr[5])
#else
#define PRINTF(...)
#define PRINT6ADDR(addr)
#define PRINTLLADDR(addr)
#endif

enum {
	TURN_ON    = 1,
	TURN_OFF   = 2,
};

uint8_t boca1;
uint8_t boca2;
uint8_t boca3;
uint8_t boca4;
uint8_t forno;
float temperature;

/******************************************************************************/
#if REST_RES_STATUS

RESOURCE(status, METHOD_GET, "stove/status", "title=\"Stove status\";rt=\"Text\"");

void status_handler(void* request, void* response, uint8_t *buffer,
							uint16_t preferred_size, int32_t *offset)
{
	char res[REST_MAX_CHUNK_SIZE];
	coap_set_header_content_type(response, TEXT_PLAIN);
	snprintf(res, REST_MAX_CHUNK_SIZE, "%d %d %d %d %d %d",
					boca1, boca2, boca3, boca4, forno, (int)temperature);
	coap_set_payload(response, res, strlen(res));
}
#endif

PROCESS(stove_process, "Stove process");
AUTOSTART_PROCESSES(&stove_process);

PROCESS_THREAD(stove_process, ev, data)
{
	PROCESS_BEGIN();

	PRINTF("Lamp process started\n");
	boca1 = boca4 = forno = TURN_ON;
	boca2 = boca3 = TURN_OFF;
	temperature = 50.0;

	/* Initialize the REST engine. */
	rest_init_engine();

	/* Activate the application-specific resources. */
	#if REST_RES_STATUS
	rest_activate_resource(&resource_status);
	#endif

	/* Define application-specific events here. */
	while(1) {
		PROCESS_WAIT_EVENT();
		#if defined (PLATFORM_HAS_BUTTON)
		if (ev == sensors_event && data == &button_sensor) {
			PRINTF("BUTTON\n");
		}
		#endif /* PLATFORM_HAS_BUTTON */
	} /* while (1) */

	PROCESS_END();
}
