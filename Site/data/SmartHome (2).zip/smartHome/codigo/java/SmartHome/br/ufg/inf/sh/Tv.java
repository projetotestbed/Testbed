package br.ufg.inf.sh;

import java.net.DatagramPacket;
import java.net.InetAddress;
import javax.swing.JPanel;

/**
 *
 * @author brunoos
 */
public class Tv extends Appliance {

    private TvPanel panel;

    public Tv(String id, InetAddress addr, int port, int x, int y) {
        setId(id);
        setAddress(addr);
        setPort(port);
        panel = new TvPanel(this);
        loadImage("br/ufg/inf/sh/tv.jpg", x, y);
    }

    public JPanel getPanel() {
        return panel;
    }

    public void process(DatagramPacket packet) {
        byte[] data = packet.getData();
        switch (data[0]) {
            case Util.RESP_GET_STATUS:
                panel.setStatus(data[1]);
                panel.setChannel(data[2]);
                panel.setVolume(data[3]);
                break;
            case Util.RESP_GET_VOLUME:
                panel.setVolume(data[1]);
                break;
            case Util.RESP_GET_CHANNEL:
                panel.setChannel(data[1]);
                break;
        }
    }
}
