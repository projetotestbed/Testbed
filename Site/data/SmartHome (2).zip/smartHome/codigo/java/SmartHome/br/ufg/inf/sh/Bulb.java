package br.ufg.inf.sh;

import java.net.DatagramPacket;
import java.net.InetAddress;
import javax.swing.JPanel;

/**
 *
 * @author brunoos
 */
public class Bulb extends Appliance {

    private BulbPanel panel;

    public Bulb(String id, InetAddress addr, int port, int x, int y) {
        setId(id);
        setAddress(addr);
        setPort(port);
        panel = new BulbPanel(this);
        loadImage("br/ufg/inf/sh/lampada.jpg", x, y);
    }

    @Override
    public void process(DatagramPacket packet) {
        byte[] data = packet.getData();
        if (data[0] == Util.RESP_GET_STATUS)
            panel.setStatus(data[1] == Util.TURN_OFF ? "Off" : "On");
    }
    
    @Override
    public JPanel getPanel() {
        return panel;
    }
}
