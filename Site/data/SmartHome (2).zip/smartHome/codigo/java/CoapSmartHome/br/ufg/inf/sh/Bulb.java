package br.ufg.inf.sh;

import java.net.DatagramPacket;
import java.net.InetAddress;
import java.util.logging.Level;

import javax.swing.JPanel;

import ch.ethz.inf.vs.californium.CaliforniumLogger;
import ch.ethz.inf.vs.californium.Utils;
import ch.ethz.inf.vs.californium.coap.MediaTypeRegistry;
import ch.ethz.inf.vs.californium.coap.Response;

/**
 *
 * @author brunoos
 */
public class Bulb extends Appliance {

    private BulbPanel panel;
    private Response response;
    
    static {
		CaliforniumLogger.initialize();
		CaliforniumLogger.setLevel(Level.WARNING);
	}
    
    public Bulb(String id, InetAddress addr, int port, int x, int y) {
        setId(id);
        setAddress(addr);
        setPort(port);
        panel = new BulbPanel(this);
        loadImage("br/ufg/inf/sh/lampada.jpg", x, y);
    }

    public void setResponse(Response r){
    	response = r;
    }
    
    @Override
    public void process(DatagramPacket packet) {
		if (response != null) {
			String linkFormat = response.getPayloadString();
			int data = Integer.parseInt(linkFormat);
			panel.setStatus(data == Util.TURN_OFF ? "Off" : "On");
		}
		response = null;
    }
    
    @Override
    public JPanel getPanel() {
        return panel;
    }
}
