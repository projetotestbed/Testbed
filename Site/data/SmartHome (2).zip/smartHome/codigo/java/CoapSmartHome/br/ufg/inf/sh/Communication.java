package br.ufg.inf.sh;

import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;

/**
 *
 * @author brunoos
 */
public class Communication extends Thread {

    private DatagramSocket socket;

    private static Communication instance;

    public static Communication getInstance() {
        if (instance == null) {
            instance = new Communication();
            instance.start();
        }
        return instance;
    }

    private Communication() {
        try {
            socket = new DatagramSocket(9000);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void run() {
        byte[] buf = new byte[1024];
        while (true) {
            try {
                DatagramPacket rPacket = new DatagramPacket(buf, buf.length);
                socket.receive(rPacket);
                Appliance a = ApplianceDAO.getInstance().findApplianceByAddress(rPacket.getAddress());
                a.process(rPacket);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    public void send(InetAddress addr, int port, byte[] data) {
        try {
            DatagramPacket sPacket = new DatagramPacket(data, data.length);
            sPacket.setAddress(addr);
            sPacket.setPort(port);
            socket.send(sPacket);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
