package br.ufg.inf.sh;

import java.net.DatagramPacket;
import java.net.InetAddress;
import java.util.StringTokenizer;
import java.util.logging.Level;

import javax.swing.JPanel;

import ch.ethz.inf.vs.californium.CaliforniumLogger;
import ch.ethz.inf.vs.californium.coap.Response;

/**
 *
 * @author brunoos
 */
public class Tv extends Appliance {

    private TvPanel panel;
    private Response response;
    private byte response_type;
    
    static {
		CaliforniumLogger.initialize();
		CaliforniumLogger.setLevel(Level.WARNING);
	}
    
    public Tv(String id, InetAddress addr, int port, int x, int y) {
        setId(id);
        setAddress(addr);
        setPort(port);
        panel = new TvPanel(this);
        loadImage("br/ufg/inf/sh/tv.jpg", x, y);
    }

    public JPanel getPanel() {
        return panel;
    }

    public void setResponse(Response r, byte type){
    	response = r;
    	response_type = type;
    }
    
    public void process(DatagramPacket packet) {
    	if (response != null) {
			String linkFormat = response.getPayloadString();
			switch (response_type) {
	            case Util.RESP_GET_STATUS:
	            	StringTokenizer data = new StringTokenizer(linkFormat, " \n");
	                panel.setStatus(Byte.parseByte(data.nextToken()));
	                panel.setVolume(Byte.parseByte(data.nextToken()));
	                panel.setChannel(Byte.parseByte(data.nextToken()));
	                break;
	            case Util.RESP_GET_VOLUME:
	                panel.setVolume(Byte.parseByte(linkFormat));
	                break;
	            case Util.RESP_GET_CHANNEL:
	                panel.setChannel(Byte.parseByte(linkFormat));
	                break;
	        }
		}
		response = null;
		response_type = 0;
    }
}
