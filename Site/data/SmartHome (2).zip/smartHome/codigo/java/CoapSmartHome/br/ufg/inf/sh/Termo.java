package br.ufg.inf.sh;

import java.net.DatagramPacket;
import java.net.InetAddress;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.StringTokenizer;
import java.util.logging.Level;

import javax.swing.JPanel;

import ch.ethz.inf.vs.californium.CaliforniumLogger;
import ch.ethz.inf.vs.californium.coap.Response;

/**
 *
 * @author brunoos
 */
public class Termo extends Appliance {

    private TermoPanel panel;
    private Response response;
    private byte response_type;
    
    static {
		CaliforniumLogger.initialize();
		CaliforniumLogger.setLevel(Level.WARNING);
	}
    
    public Termo(String id, InetAddress addr, int port, int x, int y) {
        setId(id);
        setAddress(addr);
        setPort(port);
        panel = new TermoPanel(this);
        loadImage("br/ufg/inf/sh/termo.jpg", x, y);
    }

    @Override
    public JPanel getPanel() {
        return panel;
    }

    public void setResponse(Response r, byte type){
    	response = r;
    	response_type = type;
    }
    
    @Override
    public void process(DatagramPacket packet) {
    	if (response != null) {
			String linkFormat = response.getPayloadString();
			switch (response_type) {
	            case Util.RESP_GET_STATUS:
	            	StringTokenizer data = new StringTokenizer(linkFormat, " \n");
	                panel.setStatus(Byte.parseByte(data.nextToken()));
	                panel.setTemperature(Float.parseFloat(data.nextToken()));
	                break;
	            case Util.RESP_GET_TEMPERATURE:
	                panel.setTemperature(Float.parseFloat(linkFormat));
	                break;
	        }
		}
		response = null;
		response_type = 0;
    }

}
