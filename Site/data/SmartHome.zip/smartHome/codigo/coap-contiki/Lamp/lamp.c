#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "contiki.h"
#include "contiki-net.h"


/* Define which resources to include to meet memory constraints. */
#define REST_RES_STATUS 1
#define REST_RES_CONTROL 1

#include "erbium.h"
#include "er-coap-13.h"

#if defined (PLATFORM_HAS_BUTTON)
#include "dev/button-sensor.h"
#endif
#if defined (PLATFORM_HAS_LEDS)
#include "dev/leds.h"
#endif
#if defined (PLATFORM_HAS_LIGHT)
#include "dev/light-sensor.h"
#endif

#define DEBUG 0
#if DEBUG
#define PRINTF(...) printf(__VA_ARGS__)
#define PRINT6ADDR(addr) PRINTF("[%02x%02x:%02x%02x:%02x%02x:%02x%02x:%02x%02x:%02x%02x:%02x%02x:%02x%02x]", ((uint8_t *)addr)[0], ((uint8_t *)addr)[1], ((uint8_t *)addr)[2], ((uint8_t *)addr)[3], ((uint8_t *)addr)[4], ((uint8_t *)addr)[5], ((uint8_t *)addr)[6], ((uint8_t *)addr)[7], ((uint8_t *)addr)[8], ((uint8_t *)addr)[9], ((uint8_t *)addr)[10], ((uint8_t *)addr)[11], ((uint8_t *)addr)[12], ((uint8_t *)addr)[13], ((uint8_t *)addr)[14], ((uint8_t *)addr)[15])
#define PRINTLLADDR(lladdr) PRINTF("[%02x:%02x:%02x:%02x:%02x:%02x]",(lladdr)->addr[0], (lladdr)->addr[1], (lladdr)->addr[2], (lladdr)->addr[3],(lladdr)->addr[4], (lladdr)->addr[5])
#else
#define PRINTF(...)
#define PRINT6ADDR(addr)
#define PRINTLLADDR(addr)
#endif

enum {
	TURN_ON    = 1,
	TURN_OFF   = 2,
};

static uint8_t status;

/******************************************************************************/
#if REST_RES_STATUS

RESOURCE(status, METHOD_GET, "lamp/status", "title=\"Lamp status\";rt=\"Text\"");

void status_handler(void* request, void* response, uint8_t *buffer,
							uint16_t preferred_size, int32_t *offset)
{
	char res[REST_MAX_CHUNK_SIZE];
	coap_set_header_content_type(response, TEXT_PLAIN);
	snprintf(res, REST_MAX_CHUNK_SIZE, "%d", status);
	coap_set_payload(response, res, strlen(res));
}
#endif

/******************************************************************************/
#if defined (PLATFORM_HAS_LEDS)
/******************************************************************************/
#if REST_RES_CONTROL

RESOURCE(control, METHOD_POST, "lamp/control",
		"title=\"Lamp control: ?turn=on|off\";rt=\"Control\"");

void control_handler(void* request, void* response, uint8_t *buffer,
						uint16_t preferred_size, int32_t *offset)
{
	coap_packet_t *in = (coap_packet_t *)request;
	char q[in->uri_query_len + 1];
	strncpy(q, in->uri_query, in->uri_query_len);
	q[in->uri_query_len] = '\0';
	//printf("Query = %s\n", q);

	const char s[4] = "=;&";
	char *token = NULL;
	int success = 1;

	token = strtok(q, s);
	while(token != NULL){
		if(strcmp(token, "turn") == 0){
			token = strtok(NULL, s);
			if(token == NULL){
				success = 0;
				break;
			}
			if(strcmp(token, "on") == 0){
				leds_on(LEDS_ALL);
				status = TURN_ON;
			}
			else if(strcmp(token, "off") == 0){
				leds_off(LEDS_ALL);
				status = TURN_OFF;
			}
			else{
				success = 0;
				break;
			}
		}
		// Next variable
		token = strtok(NULL, s);
	}
	
	if (!success) {
		REST.set_response_status(response, REST.status.BAD_REQUEST);
	}
}
#endif
#endif

PROCESS(lamp_process, "Lamp process");
AUTOSTART_PROCESSES(&lamp_process);

PROCESS_THREAD(lamp_process, ev, data)
{
	PROCESS_BEGIN();

	PRINTF("Lamp process started\n");
	status = TURN_OFF;

	/* Initialize the REST engine. */
	rest_init_engine();

	/* Activate the application-specific resources. */
	#if REST_RES_STATUS
	rest_activate_resource(&resource_status);
	#endif
	#if defined (PLATFORM_HAS_LEDS)
	#if REST_RES_CONTROL
	rest_activate_resource(&resource_control);
	#endif
	#endif /* PLATFORM_HAS_LEDS */

	/* Define application-specific events here. */
	while(1) {
		PROCESS_WAIT_EVENT();
		#if defined (PLATFORM_HAS_BUTTON)
		if (ev == sensors_event && data == &button_sensor) {
			PRINTF("BUTTON\n");
		}
		#endif /* PLATFORM_HAS_BUTTON */
	} /* while (1) */

	PROCESS_END();
}
