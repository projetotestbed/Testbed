package br.ufg.inf.sh;

import java.net.DatagramPacket;
import java.net.InetAddress;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import javax.swing.JPanel;

/**
 *
 * @author gttei
 */
public class Oven extends Appliance {

    private OvenPanel panel;

    public Oven(String id, InetAddress addr, int port, int x, int y) {
        setId(id);
        setAddress(addr);
        setPort(port);
        panel = new OvenPanel(this);
        loadImage("br/ufg/inf/sh/fogao.jpg", x, y);
    }

    @Override
    public JPanel getPanel() {
        return panel;
    }

    @Override
    public void process(DatagramPacket packet) {
        ByteBuffer bf = ByteBuffer.wrap(packet.getData());
        bf.order(ByteOrder.LITTLE_ENDIAN);
        byte boca1 = bf.get(1);
        byte boca2 = bf.get(2);
        byte boca3 = bf.get(3);
        byte boca4 = bf.get(4);
        byte forno = bf.get(5);
        float temp = bf.getFloat(6);
        panel.setInfo(boca1, boca2, boca3, boca4, forno, temp);
    }

}
