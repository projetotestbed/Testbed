package br.ufg.inf.sh;

/**
 *
 * @author gttei
 */
public class Util {
    public static final byte CMD_TURN = 1;
    public static final byte GET_STATUS = 2;
    public static final byte GET_CHANNEL = 3;
    public static final byte GET_VOLUME = 4;
    public static final byte GET_TEMPERATURE = 5;
    public static final byte GET_STATION = 6;
    public static final byte SET_CHANNEL = 7;
    public static final byte SET_VOLUME = 8;
    public static final byte SET_TEMPERATURE = 9;
    public static final byte SET_STATION = 10;
    public static final byte RESP_GET_STATUS = 11;
    public static final byte RESP_GET_CHANNEL = 12;
    public static final byte RESP_GET_VOLUME = 13;
    public static final byte RESP_GET_TEMPERATURE = 14;
    public static final byte RESP_GET_STATION = 15;
    
    public static final byte TURN_ON  = 1;
    public static final byte TURN_OFF = 2;
}