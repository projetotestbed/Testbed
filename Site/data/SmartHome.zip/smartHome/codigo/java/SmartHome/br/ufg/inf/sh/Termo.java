package br.ufg.inf.sh;

import java.net.DatagramPacket;
import java.net.InetAddress;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import javax.swing.JPanel;

/**
 *
 * @author brunoos
 */
public class Termo extends Appliance {

    private TermoPanel panel;

    public Termo(String id, InetAddress addr, int port, int x, int y) {
        setId(id);
        setAddress(addr);
        setPort(port);
        panel = new TermoPanel(this);
        loadImage("br/ufg/inf/sh/termo.jpg", x, y);
    }

    @Override
    public JPanel getPanel() {
        return panel;
    }

    @Override
    public void process(DatagramPacket packet) {
        ByteBuffer bf = ByteBuffer.wrap(packet.getData());
        bf.order(ByteOrder.LITTLE_ENDIAN);
        switch (bf.get(0)) {
            case Util.RESP_GET_TEMPERATURE:
                panel.setTemperature(bf.getFloat(1));
                break;
            case Util.RESP_GET_STATUS:
                panel.setStatus(bf.get(1));
                panel.setTemperature(bf.getFloat(2));
                break;
        }
    }

}
