package br.ufg.inf.sh;

import java.net.Inet6Address;
import java.net.InetAddress;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

/**
 *
 * @author brunoos
 */
public class ApplianceDAO {

    private static ApplianceDAO instance;
    private Map<InetAddress, Appliance> map;

    private ApplianceDAO() {
        try {
            map = new HashMap<InetAddress, Appliance>();

            byte[] tmp = new byte[16];
            tmp[0] = (byte) 0xFE;
            tmp[1] = (byte) 0xC0;

            tmp[15] = (byte) 0x5;
            InetAddress addr = Inet6Address.getByAddress(tmp);
            Appliance a = new Bulb("Salão", addr, 9000, 100, 170);
            map.put(a.getAddress(), a);

            tmp[15] = (byte) 0x2;
            addr = Inet6Address.getByAddress(tmp);
            a = new Bulb("Quarto 1", addr, 9000, 350, 250);
            map.put(a.getAddress(), a);

            tmp[15] = (byte) 0x3;
            addr = Inet6Address.getByAddress(tmp);
            a = new Bulb("Quarto 2", addr, 9000, 500, 250);
            map.put(a.getAddress(), a);

            tmp[15] = (byte) 0x11;
            addr = Inet6Address.getByAddress(tmp);
            a = new Bulb("Suite", addr, 9000, 530, 150);
            map.put(a.getAddress(), a);

            tmp[15] = (byte) 0x6;
            addr = Inet6Address.getByAddress(tmp);
            a = new Tv("TV Salão", addr, 9000, 100, 70);
            map.put(a.getAddress(), a);

            tmp[15] = (byte) 0x8;
            addr = Inet6Address.getByAddress(tmp);
            a = new Radio("Rádio Salão", addr, 9000, 100, 300);
            map.put(a.getAddress(), a);
            
            tmp[15] = (byte) 0x9;
            addr = Inet6Address.getByAddress(tmp);
            a = new Oven("Fogão", addr, 9000, 220, 70);
            map.put(a.getAddress(), a);

            tmp[15] = (byte) 0x10;
            addr = Inet6Address.getByAddress(tmp);
            a = new Termo("Termostato", addr, 9000, 200, 300);
            map.put(a.getAddress(), a);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static ApplianceDAO getInstance() {
        if (instance == null) {
            instance = new ApplianceDAO();
        }
        return instance;
    }

    public List<Appliance> getAppliances() {
        return new LinkedList<Appliance>(map.values());
    }
    
    public Appliance findApplianceByAddress(InetAddress addr) {
        return map.get(addr);
    }
}
