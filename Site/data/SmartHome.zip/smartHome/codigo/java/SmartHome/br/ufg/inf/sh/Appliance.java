package br.ufg.inf.sh;

import java.awt.Graphics;
import java.awt.Rectangle;
import java.awt.image.BufferedImage;
import java.net.DatagramPacket;
import java.net.InetAddress;
import javax.imageio.ImageIO;
import javax.swing.JPanel;

/**
 *
 * @author brunoos
 */
public abstract class Appliance {

    private String id;
    private int port;
    private InetAddress addr;
    private Rectangle area;
    private BufferedImage img;

    public abstract JPanel getPanel();

    public abstract void process(DatagramPacket packet);

    public void drawImage(Graphics g) {
        g.drawImage(img, area.x, area.y, null);
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public void setAddress(InetAddress addr) {
        this.addr = addr;
    }

    public InetAddress getAddress() {
        return addr;
    }

    public int getPort() {
        return port;
    }

    public void setPort(int port) {
        this.port = port;
    }

    public Rectangle getArea() {
        return new Rectangle(area);
    }

    public void setArea(Rectangle r) {
        area = new Rectangle(r);
    }

    public int getX() {
        return area.x;
    }

    public int getY() {
        return area.y;
    }

    public int getWidth() {
        return area.width;
    }

    public int getHeight() {
        return area.height;
    }

    public void loadImage(String file, int x, int y) {
        try {
            img = ImageIO.read(ClassLoader.getSystemResourceAsStream(file));
            area = new Rectangle(x, y, img.getWidth(), img.getHeight());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
