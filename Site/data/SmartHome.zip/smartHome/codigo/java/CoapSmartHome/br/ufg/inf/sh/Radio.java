package br.ufg.inf.sh;

import java.net.DatagramPacket;
import java.net.InetAddress;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.StringTokenizer;
import java.util.logging.Level;

import javax.swing.JPanel;

import ch.ethz.inf.vs.californium.CaliforniumLogger;
import ch.ethz.inf.vs.californium.coap.Response;

/**
 *
 * @author gttei
 */
public class Radio extends Appliance {

    private RadioPanel panel;
    private Response response;
    private byte response_type;
    
    static {
		CaliforniumLogger.initialize();
		CaliforniumLogger.setLevel(Level.WARNING);
	}
    
    public Radio(String id, InetAddress addr, int port, int x, int y) {
        setId(id);
        setAddress(addr);
        setPort(port);
        panel = new RadioPanel(this);
        loadImage("br/ufg/inf/sh/radio.jpg", x, y);
    }

    @Override
    public JPanel getPanel() {
        return panel;
    }

    public void setResponse(Response r, byte type){
    	response = r;
    	response_type = type;
    }
    
    @Override
    public void process(DatagramPacket packet) {
    	if (response != null) {
			String linkFormat = response.getPayloadString();
			switch (response_type) {
	            case Util.RESP_GET_STATUS:
	            	StringTokenizer data = new StringTokenizer(linkFormat, " \n");
	                panel.setStatus(Byte.parseByte(data.nextToken()));
	                panel.setVolume(Byte.parseByte(data.nextToken()));
	                panel.setChannel(Float.parseFloat(data.nextToken()));
	                break;
	            case Util.RESP_GET_VOLUME:
	                panel.setVolume(Byte.parseByte(linkFormat));
	                break;
	            case Util.RESP_GET_STATION:
	                panel.setChannel(Float.parseFloat(linkFormat));
	                break;
	        }
		}
		response = null;
		response_type = 0;
    }

}
