package br.ufg.inf.sh;

import java.net.DatagramPacket;
import java.net.InetAddress;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.StringTokenizer;
import java.util.logging.Level;

import javax.swing.JPanel;

import ch.ethz.inf.vs.californium.CaliforniumLogger;
import ch.ethz.inf.vs.californium.coap.Response;

/**
 *
 * @author gttei
 */
public class Oven extends Appliance {

    private OvenPanel panel;
    private Response response;
    
    static {
		CaliforniumLogger.initialize();
		CaliforniumLogger.setLevel(Level.WARNING);
	}
    
    public Oven(String id, InetAddress addr, int port, int x, int y) {
        setId(id);
        setAddress(addr);
        setPort(port);
        panel = new OvenPanel(this);
        loadImage("br/ufg/inf/sh/fogao.jpg", x, y);
    }

    @Override
    public JPanel getPanel() {
        return panel;
    }

    public void setResponse(Response r){
    	response = r;
    }
    
    @Override
    public void process(DatagramPacket packet) {
    	if (response != null) {
			String linkFormat = response.getPayloadString();
			StringTokenizer data = new StringTokenizer(linkFormat, " \n");
			byte boca1 = Byte.parseByte(data.nextToken());
	        byte boca2 = Byte.parseByte(data.nextToken());
	        byte boca3 = Byte.parseByte(data.nextToken());
	        byte boca4 = Byte.parseByte(data.nextToken());
	        byte forno = Byte.parseByte(data.nextToken());
	        float temp = Float.parseFloat(data.nextToken());
	        panel.setInfo(boca1, boca2, boca3, boca4, forno, temp);
		}
		response = null;
    }

}
