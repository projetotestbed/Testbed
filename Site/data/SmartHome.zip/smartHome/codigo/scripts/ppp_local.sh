#!/bin/bash

sudo pppd debug passive noauth nodetach 115200 socket 192.168.254.2:60001 \
  nocrtscts nocdtrcts lcp-echo-interval 0 noccp noip ipv6 ::23,::24 
